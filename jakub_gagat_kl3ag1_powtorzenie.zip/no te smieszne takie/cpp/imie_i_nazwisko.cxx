#include <iostream>

using namespace std;

int main(int argc, char **argv)
{
    string a, b;
	cout << "Podaj swoje imię: " << endl;
    cin >> a;
    cout << "Podaj nazwisko kolegi: " << endl;
    cin >> b;
    
    cout <<"Okej, nie uwierzysz, ale wyszło mi, że jesteś " << a << " " << b;
    
	return 0;
}
